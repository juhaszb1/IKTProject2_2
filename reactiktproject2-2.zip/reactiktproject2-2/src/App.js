import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import './App.css';
import MusicListPage from './MusicListPage';
import NewMusicPage from './NewMusicPage';
import UpdateMusicPage from './UpdateMusicPage';
import DeleteMusicPage from './DeleteMusicPage';
import NewGenrePage from './NewGenrePage';
import GenreListPage from './GenreListPage';
import DeleteGenrePage from './DeleteGenrePage';

export default function App() {
  return (
    <Router>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav">
            <li className="nav-item">
              <NavLink to="/" className="nav-link">
                <span className="nav-link">Musics</span>
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/genre" className="nav-link">
                <span className="nav-link">Genres</span>
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/new-music" className="nav-link">
                <span className="nav-link">New music</span>
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/new-genre" className="nav-link">
                <span className="nav-link">New genre</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<MusicListPage />} />
        <Route path="/genre" element={<GenreListPage />} />
        <Route path="/new-music" element={<NewMusicPage />} />
        <Route path="/update-music/:id" element={<UpdateMusicPage />} />
        <Route path="/delete-music/:id" element={<DeleteMusicPage />} />
        <Route path="/new-genre" element={<NewGenrePage />} />
        <Route path='/delete-genre/:id' element={<DeleteGenrePage />}/>
      </Routes>
    </Router>
  );
}