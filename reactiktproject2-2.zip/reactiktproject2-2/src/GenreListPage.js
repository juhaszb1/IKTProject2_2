import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import './App.css';

export default function GenreListPage() {
    const [genres, setGenres] = useState([]);

    useEffect(() => {
        fetch("https://localhost:7126/genre")
            .then((response) => response.json())
            .then((data) => setGenres(data))
            .catch((error) => console.log(error));
    }, []);

    return (
        <div className="container">
            <div className="row">
                <h2>Genres</h2>
                {genres.map((genre) => (
                    <div key={genre.id} className="card col-md-4 cards" style={{ width: "18rem" }}>
                        <div className="card-body">
                            <h5 className="card-title"><b>Genre Id:</b> {genre.id}</h5>
                            <h5 className="card-title"><b>Genre name:</b> {genre.name}</h5>
                            <hr></hr>
                            <NavLink key={genre.id + 2} to={`/delete-genre/${genre.id}`}>
                                <button className="btn btn-danger">Törlés</button>
                            </NavLink>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}