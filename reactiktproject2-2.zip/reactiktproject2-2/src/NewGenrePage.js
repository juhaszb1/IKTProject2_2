import { useNavigate } from "react-router-dom";

export default function NewGenrePage() {
    const navigate = useNavigate();

    return (
        <div className="container">
            <h2>New Genre</h2>
            <form onSubmit={(e) => {
                e.preventDefault();
                fetch("https://localhost:7126/genre", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        name: e.target.name.value,
                    })
                })
                    .then(() => {
                        navigate("/genre");
                    }).catch((error) => console.log(error));
            }}>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Name:</label>
                    <div>
                        <input type="text" name="name" className="form-control" />
                    </div>
                </div>
                <button type="submit" className="btn btn-success">Küldés</button>
            </form>
        </div>
    );
}