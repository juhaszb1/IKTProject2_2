import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

export default function DeleteMusicPage() {
    const params = useParams();
    const id = params.id;
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            await fetch(`https://localhost:7126/music/${id}`, {
                method: "DELETE"
            });
            navigate("/");
        })();
    })

    return (
        <></>
    );
}