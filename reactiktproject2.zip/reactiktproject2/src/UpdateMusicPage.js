import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

export default function UpdateMusicPage() {
    const params = useParams();
    const id = params.id;
    const navigate = useNavigate();
    const [music, setMusic] = useState([]);
    const [modname, setModname] = useState("");
    const [modpublicationYear, setModpublicationYear] = useState("");
    const [modperformer, setModperformer] = useState("");
    const [modgenreId, setModgenreId] = useState("");

    useEffect(() => {
        (async () => {
            const response = await fetch(`https://localhost:7126/music/${id}`);
            const data = await response.json();
            setMusic(data);
            setModname(data.name);
            setModpublicationYear(data.publicationYear);
            setModperformer(data.performer);
            setModgenreId(data.genreId);
        })();
    }, [id, modname, modpublicationYear, modperformer, modgenreId]);

    const modName = (e) => {
        setModname(e.target.value);
    };

    const modPublicationYear = (e) => {
        setModpublicationYear(e.target.value);
    };

    const modPerformer = (e) => {
        setModperformer(e.target.value);
    };

    const modGenreId = (e) => {
        setModgenreId(e.target.value);
    }

    return (
        <div className="container">
            <h2>Update Music</h2>
            <form onSubmit={(e) => {
                e.preventDefault();
                fetch(`https://localhost:7126/music/${id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        name: e.target.name.value,
                        publicationYear: e.target.publicationYear.value,
                        performer: e.target.performer.value,
                        genreId: e.target.genreId.value
                    })
                })
                    .then(() => {
                        navigate("/");
                    }).catch((error) => console.log(error));
            }}>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Name:</label>
                    <div>
                        <input type="text" name="name" className="form-control" defaultValue={music.name} onChange={modName} />
                    </div>
                </div>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Publication Year:</label>
                    <div>
                        <input type="number" name="publicationYear" className="form-control" defaultValue={music.publicationYear} onChange={modPublicationYear} />
                    </div>
                </div>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Performer:</label>
                    <div>
                        <input type="text" name="performer" className="form-control" defaultValue={music.performer} onChange={modPerformer} />
                    </div>
                </div>
                <div className="form-group row pb-3">
                    <label className="col-sm-3 col-form-label">Genre Id:</label>
                    <div>
                        <input type="number" name="genreId" className="form-control" defaultValue={music.genreId} onChange={modGenreId} />
                    </div>
                </div>
                <button type="submit" className="btn btn-success">Küldés</button>
            </form>
        </div>
    );
}