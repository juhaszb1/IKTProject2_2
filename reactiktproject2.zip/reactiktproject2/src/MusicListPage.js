import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import './App.css';

export default function MusicListPage() {
    const [musics, setMusics] = useState([]);
    const [genres, setGenres] = useState([]);

    useEffect(() => {
        fetch("https://localhost:7126/music")
            .then((response) => response.json())
            .then((data) => setMusics(data))
            .catch((error) => console.log(error));
    }, []);

    useEffect(() => {
        fetch("https://localhost:7126/genre")
            .then((response) => response.json())
            .then((data) => setGenres(data))
            .catch((error) => console.log(error));
    })

    return (
        <div className="container">
            <div className="row">
                <h2>Musics</h2>
                {musics.map((music) => (
                    <div key={music.id} className="card col-md-4 cards" style={{ width: "18rem", backgroundColor: "#1DB954" }}>
                        <div className="card-body">
                            <h5 className="card-title"><b>Music name:</b> {music.name}</h5>
                            <h5 className="card-title"><b>Publication year:</b> {music.publicationYear}</h5>
                            <h5 className="card-title"><b>Performer:</b> {music.performer}</h5>
                            <h5 className="card-title"><b>Genre Id:</b> {music.genreId}</h5>
                            {genres.map((genre) => genre.id === music.genreId ? <h5><b>Genre name:</b> {genre.name}</h5> : null)}
                            <hr></hr>
                            <NavLink key={music.id + 1} to={`/update-music/${music.id}`}>
                                <button className="btn btn-warning">Módosítás</button>
                            </NavLink>
                            <NavLink key={music.id + 2} to={`/delete-music/${music.id}`}>
                                <button className="btn btn-danger">Törlés</button>
                            </NavLink>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}