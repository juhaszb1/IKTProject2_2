﻿using IKTProject2.Models;
using IKTProject2.Models.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace IKTProject2.Controllers
{
    [Route("genre")]
    [ApiController]
    public class GenreController : ControllerBase
    {
        [HttpGet]
        public ActionResult<Genre> GetGenre()
        {
            using (var context = new MusicsContext()) 
            {
                try
                {
                    var request = context.Genres.ToList();
                    return Ok(request); 
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("{id}")]
        public ActionResult<Genre> GetGenreWithId(int id)
        {
            using (var context = new MusicsContext())
            {
                try
                {
                    var result = context.Genres.Where(x => x.Id == id).ToList();
                    return Ok(result);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost]
        public ActionResult<Genre> PostGenre(PostGenreDto postGenreDto)
        {
            var genre = new Genre
            {
                Name = postGenreDto.Name,
            };
            using (var context = new MusicsContext())
            {
                try
                {
                    context.Genres.Add(genre);
                    context.SaveChanges();
                    return Ok("Sikeres adathozzáadás!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPut("{id}")]
        public ActionResult<Genre> PutGenre(int id, PutGenreDto putGenreDto)
        {
            using (var context = new MusicsContext())
            {
                var changedGenre = context.Genres.FirstOrDefault(x => x.Id == id);
                try
                {
                    changedGenre!.Name = putGenreDto.Name;
                    context.Genres.Update(changedGenre);
                    context.SaveChanges();
                    return Ok("Sikeres módosítás!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<Genre> DeleteGenre(int id)
        {
            using (var context = new MusicsContext())
            {
                try
                {
                    var deletedGenre = context.Genres.FirstOrDefault(x =>x.Id == id);
                    context.Genres.Remove(deletedGenre!);
                    context.SaveChanges();
                    return Ok("Sikeres törlés!");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }
    }
}
