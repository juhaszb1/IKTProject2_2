﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace IKTProject2.Models;

public partial class Music
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public int? PublicationYear { get; set; }
    public string? Performer { get; set; }
    public int? GenreId { get; set; }
    [JsonIgnore]
    public virtual Genre? Genre { get; set; }
}
