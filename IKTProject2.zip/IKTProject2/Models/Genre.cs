﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace IKTProject2.Models;

public partial class Genre
{
    public int Id { get; set; }
    public string? Name { get; set; }
    [JsonIgnore]
    public virtual ICollection<Music> Musics { get; set; } = new List<Music>();
}
